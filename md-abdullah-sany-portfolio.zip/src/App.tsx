/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, lazy, Suspense, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { BackgroundEffects } from './components/BackgroundEffects';
import { Preloader } from './components/Preloader';
import { Navbar } from './components/Navbar';
import { MagneticCursor } from './components/MagneticCursor';
import { Hero } from './components/Hero';

// Lazy load below-the-fold components to improve Lighthouse Performance
const About = lazy(() => import('./components/About').then(module => ({ default: module.About })));
const Skills = lazy(() => import('./components/Skills').then(module => ({ default: module.Skills })));
const Education = lazy(() => import('./components/Education').then(module => ({ default: module.Education })));
const BentoGrid = lazy(() => import('./components/BentoGrid').then(module => ({ default: module.BentoGrid })));
const Services = lazy(() => import('./components/Services').then(module => ({ default: module.Services })));
const Projects = lazy(() => import('./components/Projects').then(module => ({ default: module.Projects })));
const Stats = lazy(() => import('./components/Stats').then(module => ({ default: module.Stats })));
const FAQ = lazy(() => import('./components/FAQ').then(module => ({ default: module.FAQ })));
const Contact = lazy(() => import('./components/Contact').then(module => ({ default: module.Contact })));
const Footer = lazy(() => import('./components/Footer').then(module => ({ default: module.Footer })));
const Chatbot = lazy(() => import('./components/Chatbot').then(module => ({ default: module.Chatbot })));
const BookCollabModal = lazy(() => import('./components/BookCollabModal').then(module => ({ default: module.BookCollabModal })));

export default function App() {
  const [loading, setLoading] = useState(true);
  const [loadChatbot, setLoadChatbot] = useState(false);
  const [isBookCollabOpen, setIsBookCollabOpen] = useState(false);

  useEffect(() => {
    if (loading) return;

    let timeoutId: ReturnType<typeof setTimeout>;
    let interactionOccurred = false;

    const startLoading = () => {
      if (!interactionOccurred) {
        interactionOccurred = true;
        setLoadChatbot(true);
        cleanup();
      }
    };

    const cleanup = () => {
      clearTimeout(timeoutId);
      ['scroll', 'mousemove', 'touchstart', 'click', 'keydown'].forEach((event) =>
        window.removeEventListener(event, startLoading)
      );
    };

    // Load after 5 seconds idle
    timeoutId = setTimeout(() => {
      startLoading();
    }, 5000);

    // Load on user interaction
    ['scroll', 'mousemove', 'touchstart', 'click', 'keydown'].forEach((event) =>
      window.addEventListener(event, startLoading, { once: true, passive: true })
    );

    return cleanup;
  }, [loading]);

  return (
    <div className="min-h-screen font-sans selection:bg-electric-blue/30 selection:text-white antialiased overflow-x-hidden">
      <Helmet>
        <title>SANY.AI | MD Abdullah Sany - AI-Hybrid Developer</title>
        <meta name="description" content="MD Abdullah Sany is an AI-Hybrid Developer building intelligent digital experiences and automations." />
        <meta property="og:title" content="SANY.AI | MD Abdullah Sany" />
        <meta property="og:description" content="Architecting futuristic digital ecosystems with neural integration and seamless automation." />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="SANY.AI | MD Abdullah Sany" />
        <meta name="twitter:description" content="Architecting futuristic digital ecosystems with neural integration and seamless automation." />
      </Helmet>
      {loading ? (
        <Preloader onComplete={() => setLoading(false)} />
      ) : (
        <>
          <MagneticCursor />
          <BackgroundEffects />
          <Navbar onBookCollab={() => setIsBookCollabOpen(true)} />
          
          <main className="relative z-10 flex flex-col gap-8 md:gap-16 pb-0">
            <Hero />
            <Suspense fallback={<div className="h-32 flex items-center justify-center opacity-50"><span className="w-6 h-6 border-2 border-electric-blue border-t-transparent rounded-full animate-spin" /></div>}>
              <Stats />
              <About />
              <Skills />
              <Education />
              <Services />
              <Projects />
              <BentoGrid />
              <FAQ />
              <div className="h-12" /> {/* Spacer */}
              <Contact />
            </Suspense>
          </main>
          
          <Suspense fallback={null}>
            <Footer />
          </Suspense>

          {loadChatbot && (
            <Suspense fallback={null}>
              <Chatbot />
            </Suspense>
          )}

          <Suspense fallback={null}>
            <BookCollabModal 
              isOpen={isBookCollabOpen} 
              onClose={() => setIsBookCollabOpen(false)} 
            />
          </Suspense>
        </>
      )}
    </div>
  );
}
